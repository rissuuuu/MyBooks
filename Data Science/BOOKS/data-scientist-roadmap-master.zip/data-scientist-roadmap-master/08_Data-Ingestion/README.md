# 8_ Data Ingestion

## 1_ Summary of data formats

## 2_ Data discovery

## 3_ Data sources & Acquisition

## 4_ Data integration

## 5_ Data fusion

## 6_ Transformation & enrichment

## 7_ Data survey

## 8_ Google OpenRefine

## 9_ How much data ?

## 10_ Using ETL
