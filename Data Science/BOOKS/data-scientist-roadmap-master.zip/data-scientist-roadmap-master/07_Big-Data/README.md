# 7_ Big Data

## 1_ Map Reduc fundamentals

## 2_ Hadoop Components

## 3_ HDFS

## 4_ Data replications Principles

## 5_ Setup Hadoop

## 6_ Name & data nodes

## 7_ Job & task tracker

## 8_ M/R programming

## 9_ Sqop: Loading data in HDFS

## 10_ Flume, Scribe

## 11_ SQL with Pig

## 12_ DWH with Hive

## 13_ Scribe, Chukwa for Weblog

## 14_ Using Mahout

## 15_ Zookeeper Avro

## 16_ Storm: Hadoop Realtime

## 17_ Rhadoop, RHIPE

## 18_ RMR

## 19_ Cassandra

## 20_ MongoDB, Neo4j
