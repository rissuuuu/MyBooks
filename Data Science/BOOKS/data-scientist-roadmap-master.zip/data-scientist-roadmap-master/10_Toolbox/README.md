# 10_ Toolbox

## 1_ MS Excel with Analysis toolpack

## 2_ Java, Python

## 3_ R, Rstudio, Rattle

## 4_ Weka, Knime, RapidMiner

## 5_ Hadoop dist of choice

## 6_ Spark, Storm

## 7_ Flume, Scibe, Chukwa

## 8_ Nutch, Talend, Scraperwiki

## 9_ Webscraper, Flume, Sqoop

## 10_ tm, RWeka, NLTK

## 11_ RHIPE

## 12_ D3.js, ggplot2, Shiny

## 13_ IBM Languageware

## 14_ Cassandra, MongoDB

## 13_ Microsoft Azure, AWS, Google Cloud

## 14_ Microsoft Cognitive API

## 15_ Tensorflow

https://www.tensorflow.org/

TensorFlow is an open source software library for numerical computation using data flow graphs. 

Nodes in the graph represent mathematical operations, while the graph edges represent the multidimensional data arrays (tensors) communicated between them. 

The flexible architecture allows you to deploy computation to one or more CPUs or GPUs in a desktop, server, or mobile device with a single API. 

TensorFlow was originally developed by researchers and engineers working on the Google Brain Team within Google's Machine Intelligence research organization for the purposes of conducting machine learning and deep neural networks research, but the system is general enough to be applicable in a wide variety of other domains as well. 
